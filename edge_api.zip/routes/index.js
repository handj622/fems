var express = require('express');
var router = express.Router();
var request = require('request');
var cmd = require( "node-cmd" );

/* GET home page. */
    router.get('/kube/*', function(req, res, next) {

        var request = require('request');
        var options = {
            'method': 'GET',
            'url': 'http://127.0.0.1:8001/' + req.url.substring(6,req.url.length),
        };
        console.log(options);
        request(options, function (error, response, body) {
            if (error) throw new Error(error);

        }).pipe(res);
});

/* GET home page. */
router.get('/helm/', function(req, res, next) {
    var request = require('request');
    var options = {
        'method': 'GET',
        'url': 'http://nexus.fems.cf/repository/fems/index.yaml',
    };
    console.log(options);
    request(options, function (error, response, body) {
        if (error) throw new Error(error);

    }).pipe(res);
});

/* GET helm ls*/
router.get('/services/', function(req, res, next) {

    cmd.run(
        "helm ls -o json"
        , function( error, success, stderr ) {
            if( error ) {
                console.log( "ERROR 발생 :\n\n", error );
                var data = new Object() ;

                data.code = "error" ;

                res.setHeader('Content-Type', 'application/json');
                res.end(JSON.stringify(data));
            } else {
                console.log( "SUCCESS :\n\n", success );
                var data = new Object() ;

                data.code = "success" ;
                data.message = success;

                res.setHeader('Content-Type', 'application/json');
                res.end(JSON.stringify(data));
            }
        }
    );
});

/* GET home page. */
router.post('/helm/', function(req, res, next) {
    // helm repo 안 먹을 시
    // kubesphere에 repo info 등록
    // # helm repo add fems https://nexus.fems.cf/repository/fems

    if (req.body.version == undefined) {
        cmd.run(
            "helm repo update && helm upgrade --install " + req.body.service_name + " fems/" + req.body.service_name
            , function( error, success, stderr ) {
                if( error ) {
                    console.log( "ERROR 발생 :\n\n", error );
                    var data = new Object() ;

                    data.code = "error" ;

                    res.setHeader('Content-Type', 'application/json');
                    res.end(JSON.stringify(data));
                } else {
                    console.log( "SUCCESS :\n\n", success );
                    var data = new Object() ;

                    data.code = "success" ;
                    data.message = success;

                    res.setHeader('Content-Type', 'application/json');
                    res.end(JSON.stringify(data));
                }
            }
        );
    }
    else {
        cmd.run(
            "helm repo update && helm upgrade --install " + req.body.service_name + " fems/" + req.body.service_name + " --version " + req.body.version
            , function( error, success, stderr ) {
                if( error ) {
                    console.log( "ERROR 발생 :\n\n", error );

                    var data = new Object() ;

                    data.code = "error" ;

                    res.setHeader('Content-Type', 'application/json');
                    res.end(JSON.stringify(data));
                } else {
                    console.log( "SUCCESS :\n\n", success );

                    var data = new Object() ;

                    data.code = "success" ;
                    data.message = success;

                    res.setHeader('Content-Type', 'application/json');
                    res.end(JSON.stringify(data));
                }
            }
        );
    }
});

module.exports = router;
