# 사전 준비 사항
- Kubernetes 설치 완료
- 'kubectl proxy --port=8001' 명령어 실행(백그라운드)

# 설치 및 테스트
- npm install
- npm start